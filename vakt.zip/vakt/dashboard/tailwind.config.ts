import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        night: "#14122a",
        panel: "#1d1a3b",
        raised: "#26224a",
        line: "#2e2a55",
        ink: "#eae7fb",
        dim: "#9893c7",
        iris: "#7c6cff",
        mint: "#3ddbb0",
        amber: "#ffb454",
        rose: "#ff6b7a",
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
      },
    },
  },
} satisfies Config;

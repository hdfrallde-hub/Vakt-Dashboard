import type { Option } from "@/lib/discord";

export function Toggle({ name, defaultChecked, label }: { name: string; defaultChecked: boolean; label: string }) {
  return (
    <label className="toggle" aria-label={label}>
      <input type="checkbox" name={name} defaultChecked={defaultChecked} />
      <span />
    </label>
  );
}

export function Row({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="row">
      <div>
        <h3 className="text-[0.95rem] font-semibold">{title}</h3>
        {hint && <p className="mt-1 max-w-prose text-sm leading-relaxed text-dim">{hint}</p>}
      </div>
      <div className="flex items-start md:justify-end">{children}</div>
    </div>
  );
}

export function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-10">
      <h2 className="mb-1 text-xl font-semibold">{title}</h2>
      <div>{children}</div>
    </section>
  );
}

export function ChannelSelect({ name, options, value, empty = "Ingen vald" }: { name: string; options: Option[]; value: string | null; empty?: string }) {
  return (
    <select name={name} defaultValue={value ?? ""} className="field">
      <option value="">{empty}</option>
      {options.map((o) => (
        <option key={o.id} value={o.id}>
          {name.toLowerCase().includes("role") ? o.name : `# ${o.name}`}
        </option>
      ))}
    </select>
  );
}

export function PageHeader({ title, lead, saved }: { title: string; lead: string; saved?: boolean }) {
  return (
    <header className="mb-8 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-3xl font-bold">{title}</h1>
        <p className="mt-1 text-dim">{lead}</p>
      </div>
      {saved && (
        <p role="status" className="rounded-lg bg-mint/15 px-3 py-1.5 text-sm font-medium text-mint">
          Sparat. Boten använder ändringen inom 15 sekunder.
        </p>
      )}
    </header>
  );
}

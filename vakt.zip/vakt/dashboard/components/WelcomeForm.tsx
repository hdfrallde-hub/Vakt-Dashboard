"use client";
import { useState } from "react";
import { saveWelcome } from "@/lib/actions";
import SaveButton from "./SaveButton";
import { ChannelSelect, Row, Section, Toggle } from "./ui";
import type { Option } from "@/lib/discord";

type S = {
  welcomeEnabled: boolean;
  welcomeChannelId: string | null;
  welcomeMessage: string;
  goodbyeEnabled: boolean;
  goodbyeChannelId: string | null;
  goodbyeMessage: string;
  autoRoleId: string | null;
};

const render = (tpl: string, server: string) =>
  tpl.replaceAll("{user}", "@Alex").replaceAll("{username}", "Alex").replaceAll("{server}", server).replaceAll("{count}", "1 284");

function Preview({ text, botName, server }: { text: string; botName: string; server: string }) {
  return (
    <div className="w-full rounded-xl bg-night p-4 ring-1 ring-line" aria-live="polite">
      <div className="flex gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-iris font-display font-bold">{botName[0]}</span>
        <div className="min-w-0">
          <p className="text-sm font-semibold">
            {botName} <span className="ml-1 rounded bg-iris px-1 text-[0.65rem] font-bold">BOT</span>
          </p>
          <p className="mt-0.5 whitespace-pre-wrap break-words text-[0.95rem] leading-relaxed">
            {render(text, server).split(/(@Alex)/).map((p, i) =>
              p === "@Alex" ? (
                <span key={i} className="rounded bg-iris/25 px-0.5 text-[#c9c2ff]">
                  @Alex
                </span>
              ) : (
                p
              ),
            )}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function WelcomeForm({
  guildId, server, botName, settings, channels, roles,
}: { guildId: string; server: string; botName: string; settings: S; channels: Option[]; roles: Option[] }) {
  const [welcome, setWelcome] = useState(settings.welcomeMessage);
  const [bye, setBye] = useState(settings.goodbyeMessage);
  return (
    <form action={saveWelcome.bind(null, guildId)}>
      <Section title="Välkomstmeddelande">
        <Row title="Aktivera" hint="Skickar ett meddelande när någon går med.">
          <Toggle name="welcomeEnabled" defaultChecked={settings.welcomeEnabled} label="Aktivera välkomstmeddelande" />
        </Row>
        <Row title="Kanal">
          <ChannelSelect name="welcomeChannelId" options={channels} value={settings.welcomeChannelId} />
        </Row>
        <Row title="Meddelande" hint="Variabler: {user} nämner medlemmen, {username} namnet, {server} servern, {count} antal medlemmar.">
          <div className="w-full space-y-3">
            <textarea name="welcomeMessage" className="field" value={welcome} onChange={(e) => setWelcome(e.target.value)} maxLength={1500} />
            <Preview text={welcome} botName={botName} server={server} />
          </div>
        </Row>
      </Section>

      <Section title="Avsked">
        <Row title="Aktivera" hint="Skickar ett meddelande när någon lämnar.">
          <Toggle name="goodbyeEnabled" defaultChecked={settings.goodbyeEnabled} label="Aktivera avskedsmeddelande" />
        </Row>
        <Row title="Kanal">
          <ChannelSelect name="goodbyeChannelId" options={channels} value={settings.goodbyeChannelId} />
        </Row>
        <Row title="Meddelande">
          <div className="w-full space-y-3">
            <textarea name="goodbyeMessage" className="field" value={bye} onChange={(e) => setBye(e.target.value)} maxLength={1500} />
            <Preview text={bye} botName={botName} server={server} />
          </div>
        </Row>
      </Section>

      <Section title="Nya medlemmar">
        <Row title="Automatisk roll" hint="Ges till alla som går med. Min roll måste ligga högre än den här rollen.">
          <ChannelSelect name="autoRoleId" options={roles} value={settings.autoRoleId} empty="Ingen roll" />
        </Row>
      </Section>
      <SaveButton />
    </form>
  );
}

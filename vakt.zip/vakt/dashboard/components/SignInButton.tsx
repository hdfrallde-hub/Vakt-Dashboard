"use client";
import { signIn } from "next-auth/react";

export default function SignInButton() {
  return (
    <button className="btn px-6 py-3 text-base" onClick={() => signIn("discord", { callbackUrl: "/dashboard" })}>
      Logga in med Discord
    </button>
  );
}

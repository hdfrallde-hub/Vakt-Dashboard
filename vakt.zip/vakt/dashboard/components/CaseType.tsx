const meta: Record<string, { label: string; cls: string }> = {
  warn: { label: "Varning", cls: "bg-amber/15 text-amber" },
  kick: { label: "Kick", cls: "bg-amber/15 text-amber" },
  ban: { label: "Ban", cls: "bg-rose/15 text-rose" },
  timeout: { label: "Timeout", cls: "bg-amber/15 text-amber" },
  automod: { label: "Automod", cls: "bg-iris/20 text-[#c9c2ff]" },
};

export function CaseType({ type }: { type: string }) {
  const m = meta[type] ?? { label: type, cls: "bg-raised text-dim" };
  return <span className={`inline-block w-20 rounded-md px-2 py-0.5 text-center text-xs font-semibold ${m.cls}`}>{m.label}</span>;
}

"use client";
import { useFormStatus } from "react-dom";

export default function SaveButton() {
  const { pending } = useFormStatus();
  return (
    <button className="btn min-w-32" disabled={pending}>
      {pending ? "Sparar…" : "Spara ändringar"}
    </button>
  );
}

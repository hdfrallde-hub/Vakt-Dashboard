"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const items = [
  { href: "", label: "Översikt" },
  { href: "/moderation", label: "Moderering" },
  { href: "/welcome", label: "Välkomst" },
  { href: "/cases", label: "Ärenden" },
];
const soon = ["Roller", "Tickets", "Egna kommandon", "Embed-byggare", "Giveaways"];

export default function Sidebar({ guildId, name, icon }: { guildId: string; name: string; icon: string | null }) {
  const path = usePathname();
  const base = `/dashboard/${guildId}`;
  return (
    <aside className="border-b border-line bg-panel/60 p-4 md:sticky md:top-0 md:h-screen md:w-64 md:shrink-0 md:border-b-0 md:border-r md:p-5">
      <Link href="/dashboard" className="mb-5 flex items-center gap-3 rounded-lg p-1 hover:bg-raised">
        {icon ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={icon} alt="" className="h-10 w-10 rounded-xl" />
        ) : (
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-iris font-display font-bold">{name[0]}</span>
        )}
        <span className="min-w-0">
          <span className="block truncate font-display font-semibold">{name}</span>
          <span className="block text-xs text-dim">Byt server</span>
        </span>
      </Link>
      <nav className="flex gap-1 overflow-x-auto md:flex-col">
        {items.map((it) => {
          const href = base + it.href;
          const active = it.href === "" ? path === base : path.startsWith(href);
          return (
            <Link
              key={it.href}
              href={href}
              aria-current={active ? "page" : undefined}
              className={`whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                active ? "bg-iris/20 text-ink" : "text-dim hover:bg-raised hover:text-ink"
              }`}
            >
              {it.label}
            </Link>
          );
        })}
      </nav>
      <div className="mt-6 hidden md:block">
        <p className="px-3 pb-2 text-xs text-dim">På väg</p>
        {soon.map((s) => (
          <p key={s} className="px-3 py-1.5 text-sm text-dim/50">
            {s}
          </p>
        ))}
      </div>
    </aside>
  );
}

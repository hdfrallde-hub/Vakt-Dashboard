import { notFound, redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "./auth";
import { canManage, getUserGuilds } from "./discord";
import { prisma } from "./prisma";

export async function requireUser() {
  const session = await getServerSession(authOptions);
  if (!session?.accessToken) redirect("/");
  return session;
}

/** Kontrollerar att inloggad användare får hantera servern och att boten finns där. */
export async function requireGuild(guildId: string) {
  const session = await requireUser();
  const guilds = await getUserGuilds(session.accessToken!);
  const g = guilds.find((x) => x.id === guildId);
  if (!g || !canManage(g)) notFound();
  const dbGuild = await prisma.guild.findUnique({ where: { id: guildId } });
  if (!dbGuild) redirect("/dashboard");
  const settings = await prisma.guildSettings.upsert({ where: { guildId }, update: {}, create: { guildId } });
  return { session, guild: g, dbGuild, settings };
}

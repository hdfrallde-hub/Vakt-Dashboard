"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requireGuild } from "./access";
import { prisma } from "./prisma";

const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
const optId = (fd: FormData, k: string) => str(fd, k) || null;
const bool = (fd: FormData, k: string) => fd.get(k) === "on";
const int = (fd: FormData, k: string, min: number, max: number, fallback: number) => {
  const n = parseInt(str(fd, k), 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};

async function save(guildId: string, page: string, data: Parameters<typeof prisma.guildSettings.update>[0]["data"]) {
  await requireGuild(guildId);
  await prisma.guildSettings.update({ where: { guildId }, data });
  revalidatePath(`/dashboard/${guildId}`, "layout");
  redirect(`/dashboard/${guildId}/${page}?saved=1`);
}

export async function saveModeration(guildId: string, fd: FormData) {
  await save(guildId, "moderation", {
    logChannelId: optId(fd, "logChannelId"),
    automodSpam: bool(fd, "automodSpam"),
    spamMaxMessages: int(fd, "spamMaxMessages", 2, 20, 5),
    spamIntervalSec: int(fd, "spamIntervalSec", 2, 60, 6),
    automodLinks: bool(fd, "automodLinks"),
    automodWords: bool(fd, "automodWords"),
    bannedWords: str(fd, "bannedWords").slice(0, 2000),
    automodAction: str(fd, "automodAction") === "timeout" ? "timeout" : "delete",
  });
}

export async function saveWelcome(guildId: string, fd: FormData) {
  await save(guildId, "welcome", {
    welcomeEnabled: bool(fd, "welcomeEnabled"),
    welcomeChannelId: optId(fd, "welcomeChannelId"),
    welcomeMessage: str(fd, "welcomeMessage").slice(0, 1500) || "Välkommen {user} till {server}!",
    goodbyeEnabled: bool(fd, "goodbyeEnabled"),
    goodbyeChannelId: optId(fd, "goodbyeChannelId"),
    goodbyeMessage: str(fd, "goodbyeMessage").slice(0, 1500) || "{username} lämnade servern.",
    autoRoleId: optId(fd, "autoRoleId"),
  });
}

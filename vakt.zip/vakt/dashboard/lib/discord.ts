const API = "https://discord.com/api/v10";

export type UserGuild = { id: string; name: string; icon: string | null; owner: boolean; permissions: string };
export type Option = { id: string; name: string };

export async function getUserGuilds(token: string): Promise<UserGuild[]> {
  const r = await fetch(`${API}/users/@me/guilds`, {
    headers: { Authorization: `Bearer ${token}` },
    next: { revalidate: 30 },
  });
  return r.ok ? r.json() : [];
}

/** Ägare, administratör eller "Hantera server". */
export function canManage(g: UserGuild) {
  const p = BigInt(g.permissions);
  return g.owner || (p & BigInt(0x8)) !== BigInt(0) || (p & BigInt(0x20)) !== BigInt(0);
}

async function botGet<T>(path: string): Promise<T> {
  const r = await fetch(`${API}${path}`, {
    headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}` },
    next: { revalidate: 30 },
  });
  return r.ok ? r.json() : ([] as unknown as T);
}

export async function getTextChannels(guildId: string): Promise<Option[]> {
  const all = await botGet<{ id: string; name: string; type: number; position: number }[]>(`/guilds/${guildId}/channels`);
  return all.filter((c) => c.type === 0 || c.type === 5).sort((a, b) => a.position - b.position);
}

export async function getRoles(guildId: string): Promise<Option[]> {
  const all = await botGet<{ id: string; name: string; managed: boolean; position: number }[]>(`/guilds/${guildId}/roles`);
  return all.filter((r) => !r.managed && r.id !== guildId).sort((a, b) => b.position - a.position);
}

export const iconUrl = (id: string, icon: string | null) =>
  icon ? `https://cdn.discordapp.com/icons/${id}/${icon}.${icon.startsWith("a_") ? "gif" : "png"}?size=128` : null;

export const inviteUrl = (guildId?: string) =>
  `https://discord.com/oauth2/authorize?client_id=${process.env.DISCORD_CLIENT_ID}&scope=bot%20applications.commands&permissions=1099780098054${
    guildId ? `&guild_id=${guildId}&disable_guild_select=true` : ""
  }`;

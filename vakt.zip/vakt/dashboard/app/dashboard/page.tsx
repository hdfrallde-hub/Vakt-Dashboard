import Link from "next/link";
import { requireUser } from "@/lib/access";
import { canManage, getUserGuilds, iconUrl, inviteUrl } from "@/lib/discord";
import { prisma } from "@/lib/prisma";

export const metadata = { title: "Välj server" };

export default async function Servers() {
  const session = await requireUser();
  const guilds = (await getUserGuilds(session.accessToken!)).filter(canManage);
  const present = new Set((await prisma.guild.findMany({ select: { id: true } })).map((g) => g.id));
  const sorted = [...guilds].sort((a, b) => Number(present.has(b.id)) - Number(present.has(a.id)) || a.name.localeCompare(b.name));

  return (
    <main className="mx-auto max-w-3xl px-6 py-14">
      <h1 className="text-3xl font-bold">Välj server</h1>
      <p className="mt-1 text-dim">Du ser servrar där du kan hantera servern.</p>
      <ul className="mt-8 divide-y divide-line rounded-2xl bg-panel ring-1 ring-line">
        {sorted.length === 0 && <li className="p-6 text-dim">Du hanterar inga servrar ännu.</li>}
        {sorted.map((g) => {
          const icon = iconUrl(g.id, g.icon);
          const here = present.has(g.id);
          return (
            <li key={g.id} className="flex items-center gap-4 p-4">
              {icon ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={icon} alt="" className="h-12 w-12 rounded-xl" />
              ) : (
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-raised font-display font-bold">{g.name[0]}</span>
              )}
              <span className="min-w-0 flex-1 truncate font-medium">{g.name}</span>
              {here ? (
                <Link href={`/dashboard/${g.id}`} className="btn">Öppna</Link>
              ) : (
                <a href={inviteUrl(g.id)} className="btn btn-quiet" target="_blank" rel="noreferrer">Lägg till boten</a>
              )}
            </li>
          );
        })}
      </ul>
    </main>
  );
}

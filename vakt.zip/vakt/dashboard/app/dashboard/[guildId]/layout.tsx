import Sidebar from "@/components/Sidebar";
import { requireGuild } from "@/lib/access";
import { iconUrl } from "@/lib/discord";

export default async function GuildLayout({ children, params }: { children: React.ReactNode; params: { guildId: string } }) {
  const { guild } = await requireGuild(params.guildId);
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <Sidebar guildId={guild.id} name={guild.name} icon={iconUrl(guild.id, guild.icon)} />
      <main className="mx-auto w-full max-w-4xl flex-1 px-6 py-10 md:px-10">{children}</main>
    </div>
  );
}

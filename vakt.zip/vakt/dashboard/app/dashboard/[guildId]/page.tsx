import Link from "next/link";
import { requireGuild } from "@/lib/access";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/ui";
import { CaseType } from "@/components/CaseType";

export const metadata = { title: "Översikt" };

export default async function Overview({ params }: { params: { guildId: string } }) {
  const { guild, dbGuild, settings } = await requireGuild(params.guildId);
  const recent = await prisma.modCase.findMany({ where: { guildId: guild.id }, orderBy: { caseNumber: "desc" }, take: 5 });
  const base = `/dashboard/${guild.id}`;

  const modules = [
    { label: "Automod mot spam", on: settings.automodSpam, href: "/moderation" },
    { label: "Blockera länkar", on: settings.automodLinks, href: "/moderation" },
    { label: "Ordfilter", on: settings.automodWords, href: "/moderation" },
    { label: "Loggkanal", on: !!settings.logChannelId, href: "/moderation" },
    { label: "Välkomstmeddelande", on: settings.welcomeEnabled, href: "/welcome" },
    { label: "Avskedsmeddelande", on: settings.goodbyeEnabled, href: "/welcome" },
    { label: "Automatisk roll", on: !!settings.autoRoleId, href: "/welcome" },
  ];

  return (
    <>
      <PageHeader title={guild.name} lead={`${dbGuild.memberCount.toLocaleString("sv-SE")} medlemmar`} />
      <section className="mb-10">
        <h2 className="mb-3 text-xl font-semibold">Vad som är på</h2>
        <ul className="divide-y divide-line rounded-2xl bg-panel ring-1 ring-line">
          {modules.map((m) => (
            <li key={m.label}>
              <Link href={base + m.href} className="flex items-center justify-between gap-4 px-5 py-3.5 transition-colors hover:bg-raised">
                <span>{m.label}</span>
                <span className={`text-sm font-medium ${m.on ? "text-mint" : "text-dim"}`}>{m.on ? "På" : "Av"}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
      <section>
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="text-xl font-semibold">Senaste ärenden</h2>
          <Link href={`${base}/cases`} className="text-sm text-iris hover:underline">Visa alla</Link>
        </div>
        {recent.length === 0 ? (
          <p className="rounded-2xl bg-panel p-6 text-dim ring-1 ring-line">Inga ärenden ännu. De dyker upp här när du använder /warn, /timeout, /kick eller /ban.</p>
        ) : (
          <ul className="divide-y divide-line rounded-2xl bg-panel ring-1 ring-line">
            {recent.map((c) => (
              <li key={c.id} className="flex items-center gap-3 px-5 py-3.5">
                <span className="w-10 text-dim">#{c.caseNumber}</span>
                <CaseType type={c.type} />
                <span className="min-w-0 flex-1 truncate">{c.userTag}</span>
                <time className="text-sm text-dim">{c.createdAt.toLocaleDateString("sv-SE")}</time>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}

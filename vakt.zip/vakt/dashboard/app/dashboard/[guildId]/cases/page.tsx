import { requireGuild } from "@/lib/access";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/ui";
import { CaseType } from "@/components/CaseType";

export const metadata = { title: "Ärenden" };

export default async function Cases({ params, searchParams }: { params: { guildId: string }; searchParams: { q?: string } }) {
  const { guild } = await requireGuild(params.guildId);
  const q = searchParams.q?.trim();
  const cases = await prisma.modCase.findMany({
    where: {
      guildId: guild.id,
      ...(q ? { OR: [{ userTag: { contains: q } }, { userId: q }, { reason: { contains: q } }] } : {}),
    },
    orderBy: { caseNumber: "desc" },
    take: 100,
  });
  return (
    <>
      <PageHeader title="Ärenden" lead="All moderationshistorik, nyast först." />
      <form className="mb-5">
        <input name="q" defaultValue={q} placeholder="Sök på namn, ID eller orsak" className="field max-w-sm" aria-label="Sök ärenden" />
      </form>
      {cases.length === 0 ? (
        <p className="rounded-2xl bg-panel p-6 text-dim ring-1 ring-line">{q ? "Inga ärenden matchar sökningen." : "Inga ärenden ännu."}</p>
      ) : (
        <div className="overflow-x-auto rounded-2xl bg-panel ring-1 ring-line">
          <table className="w-full min-w-[40rem] text-left text-sm">
            <thead className="text-dim">
              <tr>
                <th className="px-5 py-3 font-medium">Nr</th>
                <th className="px-3 py-3 font-medium">Typ</th>
                <th className="px-3 py-3 font-medium">Medlem</th>
                <th className="px-3 py-3 font-medium">Moderator</th>
                <th className="px-3 py-3 font-medium">Orsak</th>
                <th className="px-5 py-3 font-medium">Datum</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {cases.map((c) => (
                <tr key={c.id}>
                  <td className="px-5 py-3 text-dim">#{c.caseNumber}</td>
                  <td className="px-3 py-3"><CaseType type={c.type} /></td>
                  <td className="px-3 py-3">{c.userTag}</td>
                  <td className="px-3 py-3 text-dim">{c.moderatorTag}</td>
                  <td className="max-w-64 truncate px-3 py-3">{c.reason ?? "–"}</td>
                  <td className="px-5 py-3 text-dim">{c.createdAt.toLocaleDateString("sv-SE")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}

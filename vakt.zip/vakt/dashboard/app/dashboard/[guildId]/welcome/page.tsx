import { requireGuild } from "@/lib/access";
import { getRoles, getTextChannels } from "@/lib/discord";
import { PageHeader } from "@/components/ui";
import WelcomeForm from "@/components/WelcomeForm";

export const metadata = { title: "Välkomst" };

export default async function Welcome({ params, searchParams }: { params: { guildId: string }; searchParams: { saved?: string } }) {
  const { guild, settings } = await requireGuild(params.guildId);
  const [channels, roles] = await Promise.all([getTextChannels(guild.id), getRoles(guild.id)]);
  return (
    <>
      <PageHeader title="Välkomst" lead="Hälsa nya medlemmar och ge dem en roll direkt." saved={!!searchParams.saved} />
      <WelcomeForm
        guildId={guild.id}
        server={guild.name}
        botName={process.env.NEXT_PUBLIC_BOT_NAME ?? "Vakt"}
        settings={settings}
        channels={channels}
        roles={roles}
      />
    </>
  );
}

import { requireGuild } from "@/lib/access";
import { getTextChannels } from "@/lib/discord";
import { saveModeration } from "@/lib/actions";
import SaveButton from "@/components/SaveButton";
import { ChannelSelect, PageHeader, Row, Section, Toggle } from "@/components/ui";

export const metadata = { title: "Moderering" };

export default async function Moderation({ params, searchParams }: { params: { guildId: string }; searchParams: { saved?: string } }) {
  const { guild, settings: s } = await requireGuild(params.guildId);
  const channels = await getTextChannels(guild.id);
  return (
    <>
      <PageHeader title="Moderering" lead="Automatiskt skydd och loggar. Manuella kommandon som /ban och /timeout fungerar alltid." saved={!!searchParams.saved} />
      <form action={saveModeration.bind(null, guild.id)}>
        <Section title="Loggar">
          <Row title="Loggkanal" hint="Ärenden, raderade och ändrade meddelanden skickas hit.">
            <ChannelSelect name="logChannelId" options={channels} value={s.logChannelId} />
          </Row>
        </Section>

        <Section title="Automod">
          <Row title="Spamskydd" hint="Raderar meddelanden när någon skickar för många på kort tid.">
            <Toggle name="automodSpam" defaultChecked={s.automodSpam} label="Spamskydd" />
          </Row>
          <Row title="Gräns för spam" hint="Så många meddelanden inom tidsfönstret räknas som spam.">
            <div className="flex items-center gap-2 text-sm text-dim">
              <input name="spamMaxMessages" type="number" min={2} max={20} defaultValue={s.spamMaxMessages} className="field w-20" aria-label="Antal meddelanden" />
              meddelanden på
              <input name="spamIntervalSec" type="number" min={2} max={60} defaultValue={s.spamIntervalSec} className="field w-20" aria-label="Sekunder" />
              sekunder
            </div>
          </Row>
          <Row title="Blockera länkar" hint="Raderar meddelanden med länkar och Discord-inbjudningar.">
            <Toggle name="automodLinks" defaultChecked={s.automodLinks} label="Blockera länkar" />
          </Row>
          <Row title="Ordfilter" hint="Raderar meddelanden som innehåller något av orden nedan.">
            <Toggle name="automodWords" defaultChecked={s.automodWords} label="Ordfilter" />
          </Row>
          <Row title="Förbjudna ord" hint="Separera med komma.">
            <textarea name="bannedWords" defaultValue={s.bannedWords} className="field" placeholder="ord1, ord2, ord3" />
          </Row>
          <Row title="Vad händer vid överträdelse" hint="Meddelandet raderas alltid. Du kan också stänga av medlemmen i 5 minuter.">
            <select name="automodAction" defaultValue={s.automodAction} className="field">
              <option value="delete">Radera meddelandet</option>
              <option value="timeout">Radera och stäng av i 5 minuter</option>
            </select>
          </Row>
        </Section>
        <SaveButton />
      </form>
    </>
  );
}

import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import SignInButton from "@/components/SignInButton";

const name = process.env.NEXT_PUBLIC_BOT_NAME ?? "Vakt";

export default async function Home() {
  if (await getServerSession(authOptions)) redirect("/dashboard");
  return (
    <main className="mx-auto grid min-h-screen max-w-5xl content-center gap-12 px-6 py-16 md:grid-cols-[1.2fr_1fr] md:items-center">
      <div>
        <p className="font-display text-lg font-semibold text-iris">{name}</p>
        <h1 className="mt-3 text-5xl font-extrabold leading-[1.05] md:text-6xl">Moderera din server utan att leta efter inställningarna.</h1>
        <p className="mt-5 max-w-md text-lg leading-relaxed text-dim">
          Varje funktion har en egen sida, en på/av-knapp och rimliga standardvärden. Logga in, välj server och börja.
        </p>
        <div className="mt-8">
          <SignInButton />
        </div>
      </div>
      <div aria-hidden className="rounded-2xl bg-panel p-6 ring-1 ring-line">
        {[
          ["Automod mot spam", true],
          ["Välkomstmeddelande", true],
          ["Blockera länkar", false],
          ["Avskedsmeddelande", false],
        ].map(([label, on]) => (
          <div key={String(label)} className="flex items-center justify-between border-t border-line py-4 first:border-t-0">
            <span className="font-medium">{label}</span>
            <span className={`relative h-6 w-11 rounded-full ${on ? "bg-mint" : "bg-line"}`}>
              <span className={`absolute top-0.5 h-5 w-5 rounded-full ${on ? "left-[1.375rem] bg-night" : "left-0.5 bg-ink"}`} />
            </span>
          </div>
        ))}
      </div>
    </main>
  );
}

import type { Metadata } from "next";
import { Bricolage_Grotesque, Figtree } from "next/font/google";
import "./globals.css";

const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display" });
const body = Figtree({ subsets: ["latin"], variable: "--font-body" });

const name = process.env.NEXT_PUBLIC_BOT_NAME ?? "Vakt";

export const metadata: Metadata = { title: { default: name, template: `%s · ${name}` }, description: "Discord-bot med en dashboard som går att hitta i." };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="sv" className={`${display.variable} ${body.variable}`}>
      <body>{children}</body>
    </html>
  );
}

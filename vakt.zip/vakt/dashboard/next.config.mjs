import { config } from "dotenv";
config({ path: "../.env" });

/** @type {import('next').NextConfig} */
export default {
  images: { remotePatterns: [{ protocol: "https", hostname: "cdn.discordapp.com" }] },
};
